#include <windows.h>
#include <tchar.h>

int main(int argc, TCHAR *argv[]) {
	MessageBox(NULL, L"HelloWord", L"Easy_Hello", MB_OK);
	return 0;
}
