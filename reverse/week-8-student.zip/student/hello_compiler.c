#include <stdio.h>
#define A "HELLOWORLD"
int main(){
    puts(A"___!!");
    return 0;
}
