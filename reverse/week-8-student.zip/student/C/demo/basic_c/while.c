#include <stdio.h>

int main(){
   int input;
   scanf("%d",&input);
   while(input > 0){
       input += 1;
   }
   printf("%d",input);
   return 0;
}
