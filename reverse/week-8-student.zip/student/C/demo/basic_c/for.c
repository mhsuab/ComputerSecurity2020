#include <stdio.h>

int main(){
   int input;
   scanf("%d",&input);
   for(int i = 0 ; i < 100; i += 1){
       printf("%d",input);
   }
   return 0;
}
