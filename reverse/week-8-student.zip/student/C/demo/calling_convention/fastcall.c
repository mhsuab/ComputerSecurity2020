#include <stdio.h>

__attribute__((fastcall)) void iCanAddThreeIntTogether(int arg1, int arg2, int arg3){
    printf("%d", arg1 + arg2 + arg3);
}

int main(){
    iCanAddThreeIntTogether(1,2,3);
    return 0;
}
