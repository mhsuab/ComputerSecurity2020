#include <stdio.h>


int main(){
    int a = 0 ;
    scanf("%d", &a);
    printf("%d", a/9);
    return 0;
}
